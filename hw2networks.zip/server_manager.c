#include "server_manager.h"

int login_client(int socket, user* users) {
    short username_length, password_length;
	int connection, client_found;
    char username[MAX_NAME_LENGTH], password[MAX_NAME_LENGTH];
    char answer;
    connection = transfer_all(socket, (char*)&username_length, 2, 'r'); //full_connection
	if(connection < 0){
		return connection;
	}
    username_length = ntohs(username_length);
    connection = transfer_all(socket, username, username_length, 'r');
	if(connection < 0){
		return connection;
	}
    username[username_length] = 0;
    connection = transfer_all(socket, (char*)&password_length, 2, 'r');
	if(connection < 0){
		return connection;
	}
	password_length = ntohs(password_length);
	connection = transfer_all(socket, password, password_length, 'r');
	if(connection < 0){
		return connection;
	}
	password[password_length] = 0;

	client_found = find_client(username, password, users, MAX_USERS);//server_utils
	if (client_found >= 0)
	{
    	users[client_found].socket_fd = socket;
		answer = 1;
	} else {
		answer = 0;
	}
	connection = transfer_all(socket, &answer, 1, 's');
	if(connection < 0){
		return connection;
	}
	/*0-not found, -1-connection closed, 1-found*/
    return (int)answer; //to seker_server
}

int answer_requests(user* users, int index, char* courses_file_path) {
    char command_code; int connection;
	connection = transfer_all(users[index].socket_fd, &command_code, 1, 'r');
	if(connection < 0){
		return connection;
	}
	if (0 == command_code) /* quit command */ {
		return -1;
	}
	if (1 == command_code) /* list_of_courses command */ {
		connection = send_list_of_courses(users[index].socket_fd, courses_file_path); //server_parser
	}
	if (2 == command_code) /* add_course command */ {
		connection = add_course(users[index].socket_fd, courses_file_path, users, MAX_USERS); //server_parser
	}
	if (3 == command_code) /* rate_course command */ {
		connection = rate_course(users[index].socket_fd, courses_file_path, users[index].name); //server_parser
	}
	if (4 == command_code) /* get_rate command */ {
		connection = get_rate(users[index].socket_fd, courses_file_path); //server_parser
	}
	if (5 == command_code) /* get_rate command */ {
		connection = broadcast(users, index, MAX_USERS); //server_parser
	}
    return connection;
}
