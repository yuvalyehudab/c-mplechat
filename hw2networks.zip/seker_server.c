#include "seker_server.h"

int main(int argc, char* argv[]) {
    int max, listening_socket, port = DEFAULT_PORT, active_connection = 1, i;//, client_socket;
    //char client_username[MAX_NAME_LENGTH];
    user users[MAX_CLIENTS];
	int first_empty_cell, waiting[MAX_CLIENTS];
	fd_set read_fds;
    if (argc < 3) {
        printf("Not enough arguments. Exiting\n");
        return 0;
    }
    if (argc > 3) {
        port = atoi(argv[3]);
		if (0 == port){
			perror("bad port");
			return -1;
		}
    }
    if(load_users_from_file(argv[1], users, MAX_CLIENTS) < 0){ //load_users_from_file
		perror("File missing or bad");
		return 1;
	}
    listening_socket = create_listening_socket(port); //server_create_sockets
	if (listening_socket < 0){
		return 1;
	}
	for (i = 0; i < MAX_CLIENTS; i++){
		waiting[i] = -1;
	}
    while (1) {
		FD_ZERO(&read_fds);
		FD_SET(listening_socket, &read_fds);
		max = listening_socket;
		first_empty_cell = -1;
		for (i = 0; i < MAX_CLIENTS; i++){
			if (waiting[i] > 0){
				FD_SET(waiting[i], &read_fds);
				max = max >= waiting[i] ? max : waiting[i];
			} else {
				if (first_empty_cell < 0)
				{
					first_empty_cell = i;
				}
			}
			if (users[i].socket_fd > 0){
				FD_SET(users[i].socket_fd, &read_fds);
				max = max >= users[i].socket_fd ? max : users[i].socket_fd;
			}
		}
		select(max + 1, &read_fds, NULL, NULL, NULL);
		for (i = 0; i < MAX_CLIENTS; i++){
			if (FD_ISSET(users[i].socket_fd, &read_fds)){
				active_connection = answer_requests(users, i, argv[2]); //server_manager
				if (active_connection < 0)
				{
					close_connection(users[i].socket_fd);
					users[i].socket_fd = -1;
				}
			}
		}
		for (i = 0; i < MAX_CLIENTS; i++){
			if (FD_ISSET(waiting[i], &read_fds)){
				active_connection = login_client(waiting[i], users); //server_manager
				if (active_connection != 0){ // +-1
					if (active_connection < 0) //-1
					{
						close_connection(waiting[i]);
					}
					waiting[i] = -1; //1-found-pass to users and clean
				}
			}
		}
		if (FD_ISSET(listening_socket, &read_fds))
		{
			if (first_empty_cell >= 0)
			{
				waiting[first_empty_cell] = create_client_socket(listening_socket); //server_create_sockets
			}
		}
		/*
        client_socket = create_client_socket(listening_socket); //server_create_sockets
        active_connection = login_client(client_socket, users, client_username); //server_manager
        if (!active_connection){
			close_connection(client_socket);
			continue;
		}
        active_connection = answer_requests(client_socket,argv[2], client_username); //server_manager
		close_connection(client_socket); //server_create_sockets
		*/
	}
    return 0;
}
