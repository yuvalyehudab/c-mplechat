//TODO are the functions here really void?

#ifndef CLIENT_PARSER_H_
#define CLIENT_PARSER_H_

#include <stdio.h>
#include <sys/socket.h> //Sockets
#include <netinet/in.h> //Internet addresses
#include <arpa/inet.h> //Working with Internet addresses
#include <netdb.h> //Domain Name Service (DNS)
#include <errno.h> //Working with errno to report errors
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include "full_connection.h"

#define PACKET_LENGTH 8192

int login_to_server(int socket, char* username, char* password);

void list_of_courses(int socket);
void add_course(int socket, char* course_number, char* course_name);
void rate_course(int socket, char* course_name, char* rating_value, char* rating_text);
void get_rate(int socket, char* course_number);
void broadcast(int socket, char* message);
void quit(int socket);

#endif /* CLIENT_PARSER_H_ */
