//get_push_message.c

#include "get_push_message.h"

int get_push_message(int socket, int waiting_for_answer){
	fd_set read_fds;
	
	FD_ZERO(&read_fds);
	if (waiting_for_answer == 0){
		FD_SET(STDIN, &read_fds);
	}
	FD_SET(socket, &read_fds);
	
	select(socket + 1, &read_fds, NULL, NULL, NULL);
	
	if (FD_ISSET(socket, &read_fds)){
		return 1;
	}
	return 0;
}