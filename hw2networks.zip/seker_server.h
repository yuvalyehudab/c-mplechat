#ifndef SEKER_SERVER_H_
#define SEKER_SERVER_H_

#include <sys/socket.h> //Sockets
#include <netinet/in.h> //Internet addresses
#include <arpa/inet.h> //Working with Internet addresses
#include <netdb.h> //Domain Name Service (DNS)
#include <errno.h> //Working with errno to report errors
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/select.h>

#include "load_users_from_file.h"
#include "server_manager.h"
#include "user.h"
#include "server_create_sockets.h"

#define MAX_CLIENTS 32
#define DEFAULT_PORT 1337
#define MAX_NAME_LENGTH 16

#endif