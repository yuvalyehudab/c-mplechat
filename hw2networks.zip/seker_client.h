#ifndef SEKER_CLIENT_H_
#define SEKER_CLIENT_H_

#include "client_connection.h"
#include "client_manager.h"

#define HOSTNAME_SIZE 1024
#define DEFAULT_PORT 1337
#define DEFAULT_HOST "localhost"

#endif