#include "server_create_sockets.h"

int create_listening_socket(short port) {
    int socketfd;
    struct sockaddr_in server;
    if ((socketfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { /* socket descriptor */
        perror("Socket failed");
		return -1;
	}
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(socketfd, (struct sockaddr*)&server, sizeof(server))) { /* socket descriptor */
        	perror("Bind failed");
        	close_connection(socketfd);
		return -1;
	}
	if (listen(socketfd, Q_LEN) < 0) { /* socket descriptor */
        	perror("Listen failed");
	        close_connection(socketfd);
		return -1;
	}
    return socketfd;
}

int create_client_socket(int listening_socket) {
    int client_socket;
    if ((client_socket = accept(listening_socket, (struct sockaddr*)0, 0)) == -1) {
        perror("Accept Failed");
    }
    return client_socket;
}

void close_connection(int socket) {
    close(socket);
}
