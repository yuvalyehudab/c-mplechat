#include "client_connection.h"

int client_connection(char* hostname, int port) {
	int socketfd;
	struct sockaddr_in server;
	struct hostent *hp;
	if ((socketfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { /* socket descriptor */
        perror("Socket failed");
		return -1;
	}
	memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    hp = gethostbyname(hostname);//check another option in grades sheet!
    if (hp == 0) {
        perror("Get host by name failed");
        close_connection(socketfd);
        return -1;
    }
    memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
    server.sin_port = htons(port);
    if (connect(socketfd, (struct sockaddr*)&server, sizeof(server)) < 0) {
        perror("Connect failed");
        close_connection(socketfd);
        return -1;
    }
    return socketfd;
}

void close_connection(int socketfd) {
    close(socketfd);
}
