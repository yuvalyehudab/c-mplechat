#ifndef SERVER_MANAGER_H
#define SERVER_MANAGER_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "user.h"
#include "full_connection.h"
#include "server_parser.h"

#define MAX_FILE_PATH 1024
#define MAX_COURSE_DESCRIPTION 2048
#define COURSE_NUMBER_LENGTH 8
#define COURSE_RATING_VALUE 4
#define MAX_USERS 32

int login_client(int socket, user* users);
int answer_requests(user* users, int index, char* courses_file_path);

#endif
