#include "client_manager.h"

char* point_to_raw_input(char* field, char* str_to_ignore);

int client_login(int socket) {
    char input_u[FIELD_LENGTH], input_p[FIELD_LENGTH], *username, *password;
	int success = 0;
	clearerr(stdin);
    printf("Welcome! Please log in.\n");
    do {
		if (feof(stdin) || ferror(stdin)){
			return -1;
		}
		username = fgets(input_u, FIELD_LENGTH, stdin);
		password = fgets(input_p, FIELD_LENGTH, stdin);
		username = point_to_raw_input(input_u, "User:");
		password = point_to_raw_input(input_p, "Password:");
		success = login_to_server(socket, username, password); //client_parser
		if (success < 0){
			return -1;
		}
    } while(!success);
    printf("Hi %s, good to see you.\n", username);
	return 0;
}

void run_requests(int socket) {
    int error, wait_for_answer;
	char command[MESSAGE_LENGTH], *command_name;
	char *param1, *param2, *param3;
	const char* delimiter = " \r\t\n"; /* Assuming there is a space between every parameter*/
	wait_for_answer = 0;
	while (1) {
		error = 0;
		//select on socket and stdin, returns only(exactly?) when one(at least) of them ready to read
		if (get_push_message(socket, wait_for_answer) == 1){ //get_push_message.c?
			short message_length;
			char message[MESSAGE_LENGTH];
			error = transfer_all(socket, (char *)&message_length, 2, 'r'); // full connection
			if (error < 0){
				break;
			}
			message_length = ntohs(message_length);
			//printf("len: %d\n", message_length);
			error = transfer_all(socket, message, message_length, 'r');
			if (error < 0){
				break;
			}
			message[message_length] = '\0';
			printf("%s", message);
			if (wait_for_answer == 1){
				wait_for_answer = 0;
			} else {
				if (message_length == 0){
					wait_for_answer = 0;
				}
			}
			continue;
		}
		command_name = fgets(command, MESSAGE_LENGTH, stdin);
		command_name = strtok(command, delimiter);
		if (command_name == NULL){
			printf("Illegal command.\n");
			continue;
		}
		if (strcmp("list_of_courses", command_name) == 0) {
			list_of_courses(socket); // client_parser
			wait_for_answer = 2;
			continue;
		}
		if (strcmp("add_course", command_name) == 0) {
			param1 = strtok(NULL, delimiter);
			param2 = strtok(NULL, "\"");
			if (param1 == NULL || param2 == NULL || param1[0] == 0 || param2[0] == 0){
				printf("Illegal command.\n");
				continue;
			}
			add_course(socket, param1, param2); // client_parser
			wait_for_answer = 1;
			continue;
		}
		if (strcmp("rate_course", command_name) == 0) {
			param1 = strtok(NULL, delimiter);
			param2 = strtok(NULL, delimiter);
			param3 = strtok(NULL, "\"");
			if (param1 == NULL || param2 == NULL || param3 == NULL || param1[0] == 0 || param2[0] == 0 || param3[0] == 0){
				printf("Illegal command.\n");
				continue;
			}
			rate_course(socket, param1, param2, param3); //client_parser
			continue;
		}
		if (strcmp("get_rate", command_name) == 0) {
			param1 = strtok(NULL, delimiter);
			if (param1 == NULL || param1[0] == 0){
				printf("Illegal command.\n");
				continue;
			}
			get_rate(socket, param1); // client_parser
			wait_for_answer = 2;
			continue;
		}
		if (strcmp("broadcast", command_name) == 0) {
			param1 = strtok(NULL, "\"");
			if (param1 == NULL || param1[0] == 0){
				printf("Illegal command.\n");
				continue;
			}
			broadcast(socket, param1); // client_parser
			continue;
		}
		if (strcmp("quit", command_name) == 0) {
			quit(socket); // client_parser
			break;
		}
		else
			printf("Illegal command.\n");
	}
}

char* point_to_raw_input(char* field, char* str_to_ignore){
	char* raw;
	if (str_to_ignore == NULL || 0 == str_to_ignore[0]){
		return NULL;
	}
	if (field == NULL || 0 == field[0]){
		return NULL;
	}
	raw = strtok(field, " ");
	if (raw == NULL || strcmp(raw, str_to_ignore) != 0){
		return NULL;
	}
	raw = strtok(NULL, " \r\t\n");
	if (raw == NULL || raw[0] == 0){
		return NULL;
	}
	return raw;
}

