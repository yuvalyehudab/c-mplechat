#include "client_parser.h"

/*int receive_message_length(int socket);
void receive_message_content(int socket, short length, char* message_data);*/

int load_on_packet(char* message_data, int count, ...); /* receives count parameters, loads them on message_data and returns the number of bytes loaded */

int login_to_server(int socket, char* username, char* password){
	int packet_size;
	char c, message_data[PACKET_LENGTH];
	c = 0;
	if(username == NULL || password == NULL){
		printf("Failed to login.\n");
		return 0;
	}
	packet_size = load_on_packet(message_data, 2, username, password);
	if (transfer_all(socket, message_data, packet_size, 's') < 0){ //full_connection
		return -1;
	}
	if (transfer_all(socket, &c, 1, 'r') < 0) {//full_connection
		return -1;
	}
	if (c == '\0'){
		printf("Failed to login.\n");
	}
	return c;
}

void list_of_courses(int socket) {
	/*char message_data[PACKET_LENGTH];
	short course_length;*/
	char command = 1;
	transfer_all(socket, &command, 1, 's'); // unite sends, close if fails!!!
	/* move it to client manager or to server!
	while ((course_length = receive_message_length(socket)) != 0) { //last msg should be 'length is 0'
        receive_message_content(socket, course_length, message_data);
        printf("%s", message_data);
	}
	*/
}

void add_course(int socket, char* course_number, char* course_name) {
    char command = 2; // add_course op code
    char message_data[PACKET_LENGTH]; // array containing course_number and course_name lengths and data
    int num_bytes = load_on_packet(message_data, 2, course_number, course_name);
	transfer_all(socket, &command, 1, 's'); // full_connection
	transfer_all(socket, message_data, num_bytes, 's'); // unite sends, close if fails!!!
	/* move it to client manager or to server!
	if (course_exists == 1) {
        printf("%s exists in the database!\n", course_number);
	}
	else {
        printf("%s added successfully.\n", course_number);
	}
	end*/
}

void rate_course(int socket, char* course_name, char* rating_value, char* rating_text) {
	char command = 3;
	char message_data[PACKET_LENGTH];
    int num_bytes = load_on_packet(message_data, 3, course_name, rating_value, rating_text);
	transfer_all(socket, &command, 1, 's');//unite sends, close if fails!!!
	transfer_all(socket, message_data, num_bytes, 's');
}

void get_rate(int socket, char* course_number) {
    //short rating_length;
	char message_data[PACKET_LENGTH]; // arr[2048];
	char command = 4;
    int num_bytes = load_on_packet(message_data, 1, course_number);
	transfer_all(socket, &command, 1, 's');//unite sends, close if fails!!!
	transfer_all(socket, message_data, num_bytes, 's');
	/* move it to client manager or to server!
	while ((rating_length = receive_message_length(socket)) != 0) { // last msg should be 'length is 0'
        receive_message_content(socket, rating_length, arr);
        printf("%s", arr);
	}
	end*/
}

void broadcast(int socket, char* message){
	char command, message_data[PACKET_LENGTH];
	int num_bytes;
	command = 5;
	num_bytes = load_on_packet(message_data, 1, message);
	transfer_all(socket, &command, 1, 's');//unite sends, close if fails!!!
	transfer_all(socket, message_data, num_bytes, 's');
}

void quit(int socket) {
	char command = 0;
	transfer_all(socket, &command, 1, 's');// unite sends, close if fails!!!
}

/*
int receive_message_length(int socket) {
    short length;
    recieve_all(socket, (char*)&length, 2);
    return (int)ntohs(length);
}

void receive_message_content(int socket, short length, char* message_data) {
    recieve_all(socket, message_data, length);
    message_data[course_length] = 0;
}

*/

int load_on_packet(char* message_data, int count, ...) {
    va_list params_list;
    int i = 0, num_bytes = 0;
    char* param;
    short param_length;
    va_start(params_list, count);
    for (i = 0 ; i < count ; i++) {
        param = va_arg(params_list, char*);
        param_length = htons(strlen(param)); // length of param, converted to network order
        memcpy(message_data + num_bytes, (void*)&param_length, 2); // param length is now loaded on the packet
        num_bytes += 2;
        memcpy(message_data + num_bytes, param, strlen(param)); // param is now loaded on the packet
        num_bytes += strlen(param);
    }
    va_end(params_list);
    return num_bytes;
}
